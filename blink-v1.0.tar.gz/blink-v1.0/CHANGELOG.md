# Changelog

## v1.0

- Initial stable release of Blink.
- Included prebuilt Blink executable and runtime assets.
- Added user-friendly installer and desktop launcher.
- Added uninstaller to remove Blink cleanly.
