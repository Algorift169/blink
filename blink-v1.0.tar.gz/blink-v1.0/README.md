# Blink v1.0

Blink is a lightweight terminal emulator for Linux desktops.

## Requirements

- Linux desktop environment with a graphical session.
- GTK 3 and VTE runtime libraries installed.
- A modern Linux distribution with a working desktop environment.

## Installation

1. Extract the `blink-v1.0.tar.gz` archive.
2. Open a terminal inside the extracted `blink-v1.0` folder.
3. Run:

```bash
./install.sh
```

4. When prompted, press ENTER to install into the current directory, or enter a custom directory.

The installer copies the complete Blink release into a hidden directory named `.blink-v1.0` and creates a desktop launcher at `~/Desktop/Blink.desktop`.

## Launching Blink

After installation, launch Blink using the desktop shortcut created on your desktop.

You can also run Blink directly from the installed folder:

```bash
~/.blink-v1.0/build/blink
```

If you installed Blink into a custom directory, run:

```bash
<your-install-path>/.blink-v1.0/build/blink
```

## Uninstall

From the release folder, run:

```bash
./uninstall.sh
```

The uninstaller removes the installed `.blink-v1.0` folder and the desktop shortcut.
