#!/usr/bin/env bash
set -euo pipefail

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[1;33m'
blue='\033[0;34m'
reset='\033[0m'

info() { printf "%b%s%b\n" "$blue" "$1" "$reset"; }
success() { printf "%b%s%b\n" "$green" "$1" "$reset"; }
error() { printf "%b%s%b\n" "$red" "$1" "$reset" >&2; }
abort() { error "$1"; exit 1; }

default_install="$HOME/.blink-v1.0"
install_dir=""

printf "%b\n" "====================================="
printf "%b\n" "Blink v1.0 Uninstaller"
printf "%b\n" "====================================="

if [[ -d "$default_install" ]]; then
  install_dir="$default_install"
else
  printf "Installation directory not found at %s\n" "$default_install"
printf "Enter the parent directory where .blink-v1.0 is installed, or press ENTER to retry %s:\n" "$HOME"
  read -r parent_dir
  if [[ -z "$parent_dir" ]]; then
    install_dir="$default_install"
  else
    parent_dir="$(realpath -m "$parent_dir")"
    if [[ "$(basename "$parent_dir")" == ".blink-v1.0" ]]; then
      install_dir="$parent_dir"
    else
      install_dir="$parent_dir/.blink-v1.0"
    fi
  fi
fi

if [[ ! -d "$install_dir" ]]; then
  abort "Installation directory not found: $install_dir"
fi

info "Removing installation: $install_dir"
rm -rf "$install_dir"

desktop_file="$HOME/Desktop/Blink.desktop"
local_app_file="$HOME/.local/share/applications/Blink.desktop"
if [[ -f "$desktop_file" ]]; then
  info "Removing desktop launcher..."
  rm -f "$desktop_file"
fi
if [[ -f "$local_app_file" ]]; then
  info "Removing application entry..."
  rm -f "$local_app_file"
fi

success "Blink successfully removed."
printf "%b\n" "====================================="
