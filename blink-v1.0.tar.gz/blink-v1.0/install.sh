#!/usr/bin/env bash
set -euo pipefail

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[1;33m'
blue='\033[0;34m'
reset='\033[0m'

info() { printf "%b%s%b\n" "$blue" "$1" "$reset"; }
success() { printf "%b%s%b\n" "$green" "$1" "$reset"; }
error() { printf "%b%s%b\n" "$red" "$1" "$reset" >&2; }
abort() { error "$1"; exit 1; }

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
current_dir="$(pwd)"

printf "%b\n" "====================================="
printf "%b\n" "Blink v1.0 Installer"
printf "%b\n" "====================================="

if [[ ! -f "$script_dir/build/blink" ]]; then
  abort "Required executable build/blink not found in release package."
fi
if [[ ! -f "$script_dir/assets/icons/terminal.svg" ]]; then
  abort "Required icon assets/icons/terminal.svg not found in release package."
fi
if [[ ! -f "$script_dir/Blink.desktop.template" ]]; then
  abort "Required Blink.desktop.template not found in release package."
fi

printf "\nWhere would you like to install Blink?\n"
printf "Press ENTER to install into the current directory.\n"
printf "Installation path(enter to skip): "
read -r install_parent

if [[ -z "$install_parent" ]]; then
  install_parent="$current_dir"
else
  install_parent="$(realpath -m "$install_parent")"
fi

install_dir="${install_parent}/.blink-v1.0"

if [[ -e "$install_dir" ]]; then
  abort "Installation directory already exists: $install_dir"
fi

mkdir -p "$install_parent"
if [[ ! -w "$install_parent" ]]; then
  abort "No write permission for $install_parent"
fi

info "Copying Blink files into $install_dir ..."
mkdir -p "$install_dir"
cp -a "$script_dir/". "$install_dir/"

chmod -R u+rwX,go+rX "$install_dir"
chmod +x "$install_dir/build/blink" "$install_dir/install.sh" "$install_dir/uninstall.sh"

desktop_file="$HOME/Desktop/Blink.desktop"
local_app_file="$HOME/.local/share/applications/Blink.desktop"
mkdir -p "$(dirname "$desktop_file")"
mkdir -p "$(dirname "$local_app_file")"
info "Creating desktop launcher..."
sed "s|__INSTALL_DIR__|$install_dir|g" "$install_dir/Blink.desktop.template" > "$desktop_file"
sed "s|__INSTALL_DIR__|$install_dir|g" "$install_dir/Blink.desktop.template" > "$local_app_file"
chmod +x "$desktop_file"
chmod +x "$local_app_file"

if [[ ! -f "$install_dir/assets/icons/terminal.svg" ]]; then
  abort "Icon installation failed."
fi
if [[ ! -f "$desktop_file" ]]; then
  abort "Desktop launcher creation failed."
fi

success "Installation complete."
printf "%b\n" "====================================="
