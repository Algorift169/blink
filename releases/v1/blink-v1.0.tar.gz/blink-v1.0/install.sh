#!/usr/bin/env bash
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RESET='\033[0m'

info()    { printf "${BLUE}%s${RESET}\n" "$1"; }
success() { printf "${GREEN}%s${RESET}\n" "$1"; }
warn()    { printf "${YELLOW}%s${RESET}\n" "$1"; }
abort()   { printf "${RED}Error: %s${RESET}\n" "$1" >&2; exit 1; }

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_REAL="$(realpath "$SOURCE_DIR")"

printf "=====================================\n"
printf "      Blink v1.0 Installer\n"
printf "=====================================\n\n"

# ----------------------------------------------------
# Install required dependencies
# ----------------------------------------------------

info "Checking and installing required dependencies..."

if ! command -v sudo >/dev/null 2>&1; then
    abort "sudo is required but is not installed."
fi

echo
echo "Blink needs to install a few system packages."
echo "You may be prompted for your sudo password."
echo

sudo -v || abort "Administrator authentication failed."

if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y \
        build-essential \
        pkg-config \
        libgtk-3-dev \
        libvte-2.91-dev \
        libgtk-3-0 \
        libvte-2.91-0

elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y \
        gcc-c++ \
        make \
        pkg-config \
        gtk3-devel \
        vte291-devel \
        gtk3 \
        vte291

elif command -v pacman >/dev/null 2>&1; then
    sudo pacman -Syu --noconfirm \
        base-devel \
        pkgconf \
        gtk3 \
        vte3

elif command -v apk >/dev/null 2>&1; then
    sudo apk add \
        build-base \
        pkgconf \
        gtk+3.0-dev \
        vte3-dev \
        gtk+3.0 \
        vte3

elif command -v zypper >/dev/null 2>&1; then
    sudo zypper install -y \
        gcc-c++ \
        make \
        pkg-config \
        gtk3-devel \
        vte291-devel \
        gtk3 \
        vte291

else
    abort "Unsupported Linux distribution. Please install the required packages manually."
fi

success "Dependencies installed."
echo
# ----------------------------------------------------
# Ask installation location
# ----------------------------------------------------

echo "Default installation location:"
echo "  $HOME/.blink-v1.0"
echo
read -rp "Install somewhere else? Enter parent directory or press ENTER: " INSTALL_PARENT

if [[ -z "$INSTALL_PARENT" ]]; then
    INSTALL_PARENT="$HOME"
else
    INSTALL_PARENT="$(realpath -m "$INSTALL_PARENT")"
fi

TARGET_DIR="$INSTALL_PARENT/.blink-v1.0"
TARGET_REAL="$(realpath -m "$TARGET_DIR")"

# ----------------------------------------------------
# Safety checks
# ----------------------------------------------------

if [[ "$TARGET_REAL" == "$SOURCE_REAL"* ]]; then
    abort "Cannot install inside the extracted release directory."
fi

if [[ "$SOURCE_REAL" == "$TARGET_REAL"* ]]; then
    abort "Source and destination overlap."
fi

[[ ! -e "$TARGET_DIR" ]] \
    || abort "$TARGET_DIR already exists."

mkdir -p "$INSTALL_PARENT"

[[ -w "$INSTALL_PARENT" ]] \
    || abort "No write permission for $INSTALL_PARENT"

# ----------------------------------------------------
# Copy files
# ----------------------------------------------------

info "Installing Blink..."

mkdir -p "$TARGET_DIR"

cp -a "$SOURCE_DIR/." "$TARGET_DIR"

chmod +x \
    "$TARGET_DIR/build/blink" \
    "$TARGET_DIR/install.sh" \
    "$TARGET_DIR/uninstall.sh"

# ----------------------------------------------------
# Desktop launcher
# ----------------------------------------------------

DESKTOP="$HOME/Desktop/Blink.desktop"
LOCAL_DESKTOP="$HOME/.local/share/applications/Blink.desktop"

mkdir -p "$HOME/Desktop"
mkdir -p "$HOME/.local/share/applications"

sed \
    "s|__INSTALL_DIR__|$TARGET_DIR|g" \
    "$TARGET_DIR/Blink.desktop.template" \
    > "$DESKTOP"

sed \
    "s|__INSTALL_DIR__|$TARGET_DIR|g" \
    "$TARGET_DIR/Blink.desktop.template" \
    > "$LOCAL_DESKTOP"

chmod +x "$DESKTOP"
chmod +x "$LOCAL_DESKTOP"

# ----------------------------------------------------
# Final verification
# ----------------------------------------------------

[[ -x "$TARGET_DIR/build/blink" ]] \
    || abort "Executable missing after installation."

[[ -f "$TARGET_DIR/assets/icons/terminal.svg" ]] \
    || abort "Icon missing after installation."

[[ -f "$DESKTOP" ]] \
    || abort "Desktop shortcut creation failed."

# ----------------------------------------------------
# Done
# ----------------------------------------------------

echo
success "Blink has been installed successfully."

echo
echo "Installation directory:"
echo "  $TARGET_DIR"

echo
echo "Run Blink from:"
echo "  • Desktop icon"
echo "  • Application menu"
echo "  • $TARGET_DIR/build/blink"

echo
printf "=====================================\n"